// 3D viewport geometry, target sizes, metal-surface contrast, and race replay.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { ART, SUBJECTS, edgeMargin, panelColumn, sceneGeometry, subjectRectangle, titleLayout } from '../site/js/stage-geometry.js';
import { barScale, barShare } from '../site/js/ratings-bars.js';
import { outlineTable, pointAt, smoothPath, startLine } from '../site/js/track-geometry.js';
import { lapClock, speedProfile, uniformClock } from '../site/js/speed-profile.js';
import {
  GRID_SPACING,
  DEFAULT_SPEED,
  SPEEDS,
  STOP_SCREEN,
  buildReplay,
  gapsAt,
  progress,
  progressesAt,
  raceTypical,
  screenClock,
  standingsAt,
  timeAtProgress,
} from '../site/js/race-replay.js';

const VIEWPORTS = [
  [375, 812],
  [390, 844],
  [768, 1024],
  [820, 1180],
  [1024, 768],
  [1100, 700],
  [1280, 800],
  [1366, 600],
  [1440, 900],
  [1920, 1080],
  [2560, 1080],
];
// ── responsive model displays and selection targets ──
for (const [width, height] of VIEWPORTS) {
  const geometry = sceneGeometry(width, height);
  const column = panelColumn(width);
  const label = `${width}x${height}`;
  const rectangles = Object.fromEntries(Object.keys(SUBJECTS).map((name) => [name, subjectRectangle(geometry, name)]));
  assert.equal(geometry.wide, Boolean(column));
  assert.equal(rectangles.driver.width, rectangles.car.width, `${label}: the models have equal display dimensions`);
  assert.equal(rectangles.driver.height, rectangles.car.height);
  for (const rectangle of Object.values(rectangles)) {
    assert.ok(rectangle.width >= 44 && rectangle.height >= 44, `${label}: large enough for keyboard and touch selection`);
    assert.ok(rectangle.x >= 0 && rectangle.x + rectangle.width <= width, `${label}: neither model is horizontally clipped`);
    assert.ok(rectangle.y >= 64 && rectangle.y + rectangle.height <= height, `${label}: both displays remain on screen`);
    if (column) assert.ok(rectangle.x >= column.right + 16, `${label}: the models stay clear of the rankings`);
  }
  const title = titleLayout(width);
  assert.ok(
    title.left >= edgeMargin(width) && title.left + title.width <= width - edgeMargin(width) + 0.1,
    `${label}: the heading fits the left column`,
  );
  if (column) {
    assert.ok(title.left + title.width <= column.right, `${label}: the title sits above the rankings`);
    assert.ok(height - (title.top + title.height + 28) - 55 >= 250, `${label}: the rankings retain useful height`);
    assert.ok(column.width > width * 0.6, `${label}: rankings occupy most of the page width`);
    assert.equal(rectangles.driver.x, rectangles.car.x, `${label}: both models align in the far-right column`);
    assert.ok(rectangles.driver.y + rectangles.driver.height < rectangles.car.y, `${label}: models are vertically stacked without overlap`);
    assert.ok(rectangles.driver.x >= width * 0.7, `${label}: models use only the far-right edge`);
  } else {
    assert.equal(rectangles.driver.x, rectangles.car.x, `${label}: compact models also form one vertical stack`);
    assert.ok(rectangles.driver.y + rectangles.driver.height < rectangles.car.y, `${label}: compact selection targets never overlap`);
    assert.ok(title.left + title.width < rectangles.driver.x, `${label}: the compact stack leaves the heading clear`);
  }
}
assert.equal(panelColumn(999), null);
assert.equal(panelColumn(1000).left, edgeMargin(1000));
for (const subject of Object.values(SUBJECTS))
  assert.ok(subject.x >= 0 && subject.y >= 0 && subject.x + subject.width <= ART.width && subject.y + subject.height <= ART.height);

// ── the bars beside the ratings ────────────────────────
assert.equal(barShare(1100, 1000, 1100), 1, 'the highest value fills the bar');
assert.equal(barShare(1000, 1000, 1100), 0, 'the bottom of the scale is empty');
assert.equal(barShare(1050, 1000, 1100), 0.5);
assert.equal(barShare(NaN, 1000, 1100), 0, 'no rating, no bar');
assert.equal(barShare(1200, 1000, 1100), 1, 'a value above the scale is held at the end');
assert.equal(barShare(900, 1000, 1100), 0, 'a value below the scale is held at the start');
assert.equal(barShare(5, 7, 7), 0, 'an empty scale gives no bar');
const scale = barScale([1101, 1081, NaN, 879, 1000]);
assert.equal(scale.high, 1101);
assert.ok(scale.low < 879 && barShare(879, scale.low, scale.high) > 0.1, 'the lowest value shown still has a bar');
assert.ok(barShare(1000, scale.low, scale.high) > barShare(879, scale.low, scale.high), 'the average is to the right of the lowest');
assert.deepEqual(barScale([]), { low: 0, high: 0 });

// ── the shape of a circuit, and how fast a car goes round it ───────────
{
  const square = [100, 100, 400, 100, 400, 400, 100, 400];
  const path = smoothPath(square);
  assert.ok(path.startsWith('M100,100C') && path.endsWith('Z'), 'the path starts at the first point and is closed');
  assert.equal(path.split('C').length - 1, 4, 'one curve for each point');
  const line = startLine(square, 10);
  assert.ok(Math.abs((line.x2 - line.x1) * 300) < 1e-9, 'the start line is across the first stretch of the track (here, horizontal)');
  assert.ok(Math.abs(Math.hypot(line.x2 - line.x1, line.y2 - line.y1) - 20) < 1e-9, 'and as long as asked');

  // the table of points at equal steps of distance
  const table = outlineTable(square, 400);
  assert.equal(table.x.length, 401);
  assert.ok(Math.hypot(table.x[400] - table.x[0], table.y[400] - table.y[0]) < 1e-9, 'the table closes on the start line');
  assert.ok(
    table.length > 1000 && table.length < 1300,
    `a smooth curve through a 300 unit square is a little shorter than its 1200 perimeter (${table.length.toFixed(0)})`,
  );
  const steps = Array.from({ length: 400 }, (_, k) => Math.hypot(table.x[k + 1] - table.x[k], table.y[k + 1] - table.y[k]));
  assert.ok(Math.max(...steps) / Math.min(...steps) < 1.05, 'the steps of the table are equal');
  assert.deepEqual(pointAt(table, 0), pointAt(table, 1), 'the start line is at 0 and at 1');
  assert.ok(Math.abs(pointAt(table, 0.5)[0] + pointAt(table, 0)[0] - 500) < 25, 'half way round a square is the opposite corner');

  // a stadium: two straights joined by two half circles of 100 m radius; the bends are slow and the straights fast
  const radius = 100;
  const flat = [];
  for (let k = 0; k <= 12; k++) flat.push(600 + Math.sin((k / 12) * Math.PI) * radius, -Math.cos((k / 12) * Math.PI) * radius); // the right bend, top to bottom
  for (let k = 1; k < 12; k++) flat.push(600 - (k * 1200) / 12, radius); // the bottom straight, right to left
  for (let k = 0; k <= 12; k++) flat.push(-600 - Math.sin((k / 12) * Math.PI) * radius, Math.cos((k / 12) * Math.PI) * radius); // the left bend, bottom to top
  for (let k = 1; k < 12; k++) flat.push(-600 + (k * 1200) / 12, -radius); // the top straight, left to right
  const lap = outlineTable(flat, 800).length * 0.5; // metres: half a unit each
  const speeds = speedProfile(flat, lap, 100);
  assert.equal(speeds.length, 100);
  assert.ok(
    Math.min(...speeds) < 0.6 * Math.max(...speeds),
    `slow bends, fast straights (${Math.min(...speeds)} to ${Math.max(...speeds)} km/h)`,
  );
  assert.ok(
    speeds.every((speed, k) => Math.abs(speed - speeds[(k + 50) % 100]) < 0.08 * Math.max(...speeds)),
    'a stadium looks the same from both ends',
  );
  const bend = Math.min(...speeds);
  assert.ok(bend > 40 && bend < 200, `a 100 m radius bend is taken at ${bend} km/h, not at a standstill and not flat out`);
  assert.ok(Math.max(...speeds) <= 306, 'nobody goes faster than the ceiling');
  // braking is harder than acceleration: the way down into a bend is shorter than the way back up
  const at = speeds.indexOf(bend);
  let down = 0;
  while (speeds[(at - down + 100) % 100] < 0.97 * Math.max(...speeds) && down < 50) down++;
  let up = 0;
  while (speeds[(at + up) % 100] < 0.97 * Math.max(...speeds) && up < 50) up++;
  assert.ok(up >= down, 'a car takes longer to get back up to speed out of a bend than to slow into it');

  // the clock of a lap
  const clock = lapClock(speeds);
  assert.equal(clock.distanceAt(0), 0);
  assert.equal(clock.distanceAt(1), 1);
  for (const f of [0.1, 0.3, 0.5, 0.77])
    assert.ok(Math.abs(clock.timeAt(clock.distanceAt(f)) - f) < 1e-9, 'timeAt is the inverse of distanceAt');
  let before = 0;
  for (let f = 0.01; f <= 1; f += 0.01) {
    assert.ok(clock.distanceAt(f) > before, 'the distance covered only grows');
    before = clock.distanceAt(f);
  }
  const slowShare = speeds.filter((speed) => speed < 0.6 * Math.max(...speeds)).length / 100;
  assert.ok(slowShare > 0.1, 'a fair part of the lap is slow');
  assert.equal(uniformClock.distanceAt(0.4), 0.4, 'with no profile every part of a lap takes its share of the time');
}

// ── the replay of a race ───────────────────────────────
{
  // laps in centiseconds; entries are [driverId, constructorId, grid, out, statusId, laps]
  const entry = (id, team, grid, out, laps) => [id, team, grid, out, 1, laps.map((seconds) => Math.round(seconds * 100))];
  const race = {
    laps: 4,
    stops: [],
    entries: [
      entry(1, 10, 1, 0, [90, 95, 90, 90]), // ahead after lap 1, passed on lap 2
      entry(2, 10, 2, 0, [92, 85, 90, 90]),
      entry(3, 20, 3, 1, [95, 95, 95]), // out after three laps (at 285 seconds)
      entry(4, 20, 0, 0, [160, 160, 160]), // from the pit lane, so slow that the leaders lap it
    ],
  };
  const replay = buildReplay(race, uniformClock);
  assert.deepEqual(
    replay.cars.map((car) => [car.id, car.team, car.slot, car.out, car.laps]),
    [
      ['1', '10', 1, false, 4],
      ['2', '10', 2, false, 4],
      ['3', '20', 3, true, 3],
      ['4', '20', 5, false, 3],
    ],
    'the cars: the pit lane is behind the last place on the grid, and the team and the number of laps are kept',
  );
  assert.equal(replay.end, 480, 'the race ends when the last car that kept racing finishes (the slow one, 3 laps of 160 seconds)');
  const state = (time) => {
    const progresses = progressesAt(replay, time);
    const standings = standingsAt(replay, time, progresses);
    return { progresses, standings, gaps: gapsAt(replay, time, progresses, standings) };
  };
  const ids = (standings) => standings.order.map((index) => replay.cars[index].id).join('');
  // the grid, then the first lap
  const start = state(0);
  assert.equal(ids(start.standings), '1234', 'at the start the cars are in grid order');
  assert.ok(
    start.progresses[0] < 0 && start.progresses[0] > start.progresses[1] && start.progresses[3] < start.progresses[2],
    'behind the line, the pole sitter nearest',
  );
  assert.equal(start.standings.lap, 1);
  assert.equal(start.standings.finished, false);
  // car 1 is ahead at the end of lap 1 (90 against 92), car 2 ahead at the end of lap 2 (177 against 185): an overtake
  assert.equal(ids(state(91).standings).slice(0, 2), '12', 'car 1 leads at the line after lap 1');
  assert.equal(ids(state(180).standings).slice(0, 2), '21', 'and car 2 has passed it by the end of lap 2');
  assert.equal(ids(state(180).standings), '2134', 'the car that retired later is still racing, in third');
  // the gap: car 2 at t = 100 is at 1 + 8/85 laps; car 1 reached that at 90 + (8/85)*95
  const gap = state(100).gaps[1];
  assert.equal(gap.kind, 'seconds');
  assert.ok(Math.abs(gap.value - (100 - (90 + (8 / 85) * 95))) < 1e-6, `a gap of ${gap.value.toFixed(3)} seconds`);
  assert.equal(state(100).gaps[0].kind, 'leader');
  // the car from the pit lane is lapped
  const late = state(300);
  assert.equal(late.gaps[3].kind, 'laps', 'a car a whole lap behind is given in laps');
  assert.equal(late.gaps[3].value, 1);
  // the retirement: after its last lap car 3 is out and last
  assert.equal(state(200).standings.racing[2], true);
  const after = state(290);
  assert.equal(after.standings.racing[2], false, 'a car that has stopped is no longer racing');
  assert.equal(after.gaps[2].kind, 'out');
  assert.equal(ids(after.standings).at(-1), '3', 'and is below everyone still racing, even a car it is ahead of on the road');
  // the finish: the leader has completed 4 laps; the others finish later, and the gap at the finish is the difference of the finishing times
  const done = state(replay.end + 5);
  assert.equal(done.standings.finished, true);
  assert.equal(done.standings.lap, 4);
  assert.equal(ids(done.standings), '214'.concat('3'), 'at the end: classified in the order they finished');
  assert.ok(
    Math.abs(done.gaps[0].value - (replay.cars[0].finish - replay.cars[1].finish)) < 1e-6,
    'the final gap is the difference of the finishing times',
  );
  assert.ok(done.progresses[0] > 4, 'a car that has finished goes on round, slowly, and does not stand on the line');
  assert.ok(done.progresses[2] === 3, 'while a car that retired stays where it stopped');

  // a red flag: no car moves for its whole length, every line is crossed at its recorded moment
  const flagged = {
    laps: 3,
    stops: [[100, 1100]],
    entries: [entry(1, 10, 1, 0, [90, 1090, 80]), entry(2, 10, 2, 0, [92, 1088, 82])],
  };
  const frozen = buildReplay(flagged, uniformClock);
  for (const car of frozen.cars) {
    const [a, b] = [progress(car, 100, uniformClock), progress(car, 1099, uniformClock)];
    assert.ok(Math.abs(b - a) < 1e-9, `car ${car.id} stands still through the red flag`);
    assert.ok(a > 1 && a < 2, 'somewhere in its second lap');
  }
  assert.ok(Math.abs(timeAtProgress(frozen.cars[0], 2, uniformClock) - 1180) < 1e-6, 'and still crosses the line when its lap times say');
  assert.ok(Math.abs(timeAtProgress(frozen.cars[1], 3, uniformClock) - 1262) < 1e-6);
  assert.ok(standingsAt(frozen, 500, progressesAt(frozen, 500)).stopped, 'the state of the race says it is stopped');
  assert.ok(!standingsAt(frozen, 1500, progressesAt(frozen, 1500)).stopped);
  assert.ok(!standingsAt(frozen, 50, progressesAt(frozen, 50)).stopped);

  // a typical lap is not pulled by a long one
  assert.ok(
    Math.abs(
      raceTypical([
        [90, 91, 92],
        [93, 1500, 95],
      ]) - 92,
    ) < 2,
    'a typical lap leaves out the very long laps',
  );
  assert.deepEqual(SPEEDS, [1, 2, 5, 10, 30, 50], 'the speeds the visitor can choose from');
  assert.equal(DEFAULT_SPEED, 10);
  assert.ok(SPEEDS.includes(DEFAULT_SPEED));
  assert.ok(GRID_SPACING > 0 && GRID_SPACING < 0.01);
  // a red flag takes the same few seconds on the screen at every speed
  for (const speed of SPEEDS) {
    const clock = screenClock([[100, 2100]], STOP_SCREEN * speed);
    assert.ok(
      Math.abs(clock.shownAt(2100) - clock.shownAt(100) - STOP_SCREEN * speed) < 1e-9,
      `at ${speed}x the stoppage is ${STOP_SCREEN * speed} seconds of race time`,
    );
    assert.ok(
      Math.abs((clock.shownAt(2100) - clock.shownAt(100)) / speed - STOP_SCREEN) < 1e-9,
      `which is ${STOP_SCREEN} seconds on the screen`,
    );
    assert.ok(Math.abs(clock.realAt(clock.shownAt(1500)) - 1500) < 1e-6, 'and the clock is its own inverse');
  }
  // a stoppage shorter than the pause is not shortened (at 50x the pause is 150 seconds of race)
  assert.equal(screenClock([[100, 220]], STOP_SCREEN * 50).realAt(400), 400);
}

// ── can it be read? ────────────────────────────────────
const css = await readFile(new URL('../site/css/stage.css', import.meta.url), 'utf8');
const block = (selector) => {
  const start = css.indexOf(selector);
  assert.ok(start >= 0, `${selector} in stage.css`);
  return css.slice(css.indexOf('{', start) + 1, css.indexOf('\n}', start));
};
const tokensOf = (text) => Object.fromEntries([...text.matchAll(/--([a-z0-9-]+):\s*([^;]+);/g)].map((m) => [m[1], m[2].trim()]));
const panelTokens = tokensOf(block('.rating-card {'));
const stageSurfaces = [...css.matchAll(/--stage-bg:\s*(#[0-9a-f]{6})/gi)].map((match) => match[1]);
assert.equal(new Set(stageSurfaces).size, 1, 'idle, hover and pinned states share one metal surface');
const resolve = (tokens, name, depth = 0) => {
  const value = tokens[name];
  const reference = value?.match(/^var\(--([a-z-]+)\)/);
  return reference && depth < 5 ? resolve(tokens, reference[1], depth + 1) : value;
};
const hex = (text) => {
  const digits = text.slice(1);
  const full = digits.length === 3 ? [...digits].map((digit) => digit + digit).join('') : digits; // #fff is #ffffff
  return [0, 2, 4].map((i) => parseInt(full.slice(i, i + 2), 16));
};
const channel = (v) => {
  const c = v / 255;
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
};
const luminance = ([r, g, b]) => 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
const contrast = (a, b) => {
  const [high, low] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (high + 0.05) / (low + 0.05);
};
// Navigation stays readable over the brightest charcoal band; panel text uses the darkest silver band.
const contrastChecks = [
  ['idle and active navigation', '#cad4de', '#283746', 4.5],
  ['active title', '#edf3f8', '#283746', 3],
  ...['ink', 'ink-2', 'ink-3', 'pos', 'neg', 'accent-text'].map((name) => [name, resolve(panelTokens, name), '#a8a8a8', 4.5]),
  ['rating bars', '#0a1a9c', '#a8a8a8', 3],
];
for (const [name, foreground, background, minimum] of contrastChecks) {
  const ratio = contrast(hex(foreground), hex(background));
  assert.ok(ratio >= minimum, `${name}: contrast ${ratio.toFixed(2)} must be at least ${minimum}`);
}
const html = await readFile(new URL('../site/index.html', import.meta.url), 'utf8');
assert.match(html, /<canvas[^>]+id="stageModels"/, 'the landing page displays live 3D models');
assert.doesNotMatch(html, /machined-paddock|pixel-paddock/, 'the rejected SVG figures are not loaded');
const workspace = await readFile(new URL('../site/js/workspace.js', import.meta.url), 'utf8');
assert.match(workspace, /const DEFAULT_ROUTE = '\/ratings'/, 'rankings are open on arrival');
console.log(`PASS 3D landing: geometry at ${VIEWPORTS.length} sizes, title and hit areas, contrast, default rankings, and race replay`);
