// The landing page has two explicit states. A model selection updates the title,
// rankings and lighting together; pointer hover never changes the active subject.
import { setEntity } from './ratings-view.js';
import { ART, panelColumn, sceneGeometry, subjectRectangle, titleLayout } from './stage-geometry.js';
import { DECK_PAGES } from './stage-pages.js';

const SUBJECTS = ['driver', 'car'];
const $ = (id) => document.getElementById(id);

export function initStage() {
  const stage = $('stage');
  if (!stage) return;
  const title = $('stageTitle'),
    ledger = $('stageLedger');
  const lead = title.querySelector('.question-lead'),
    subjectTitle = title.querySelector('.question-subject');
  const buttons = { driver: $('hotspotDriver'), car: $('hotspotCar') };
  const lights = { driver: $('driverSelectionLight'), car: $('carSelectionLight') };
  const bottomBar = stage.querySelector('.stage-bottom');
  let selected = 'driver',
    announced = '';
  const deckOpen = () => DECK_PAGES.includes(document.body.dataset.page);

  function announcePanel() {
    const detail = { open: !deckOpen(), wide: stage.dataset.layout === 'wide' };
    const next = `${JSON.stringify(detail)}:${stage.style.getPropertyValue('--track-room')}`;
    if (next === announced) return;
    announced = next;
    window.dispatchEvent(new CustomEvent('f1:panel-state', { detail }));
  }

  function layout() {
    const box = stage.getBoundingClientRect();
    if (!box.width || !box.height) return;
    const geometry = sceneGeometry(box.width, box.height);
    stage.dataset.layout = geometry.wide ? 'wide' : 'sheet';
    for (const [property, value] of Object.entries({ x: geometry.x, y: geometry.y, w: geometry.width, h: geometry.height }))
      stage.style.setProperty(`--scene-${property}`, `${value}px`);
    const column = panelColumn(box.width);
    if (column) {
      stage.style.setProperty('--panel-left', `${column.left}px`);
      stage.style.setProperty('--panel-width', `${column.width}px`);
    }
    const heading = titleLayout(box.width);
    for (const [property, value] of Object.entries({
      left: heading.left,
      top: heading.top,
      width: heading.width,
      size: heading.size,
      'lead-size': heading.leadSize,
    }))
      stage.style.setProperty(`--title-${property}`, `${value}px`);
    const ledgerTop = geometry.wide ? heading.top + heading.height + 28 : geometry.y + geometry.height + 12;
    stage.style.setProperty('--ledger-top', `${ledgerTop}px`);
    stage.style.setProperty('--bottom-space', `${bottomBar.offsetHeight}px`);
    const lowest = Math.max(
      ...SUBJECTS.map((subject) => {
        const area = subjectRectangle(geometry, subject);
        return area.y + area.height;
      }),
    );
    stage.style.setProperty('--track-room', `${Math.max(0, box.height - bottomBar.offsetHeight - lowest - 44)}px`);
    for (const subject of SUBJECTS) {
      const area = subjectRectangle(geometry, subject);
      Object.assign(buttons[subject].style, {
        left: `${area.x}px`,
        top: `${area.y}px`,
        width: `${area.width}px`,
        height: `${area.height}px`,
      });
      const light = geometry.viewports[subject];
      Object.assign(lights[subject].style, {
        left: `${(light.x / ART.width) * 100}%`,
        top: `${(light.y / geometry.artHeight) * 100}%`,
        width: `${(light.width / ART.width) * 100}%`,
        height: `${(light.height / geometry.artHeight) * 100}%`,
      });
    }
    announcePanel();
  }

  function update() {
    stage.dataset.state = 'open';
    stage.dataset.mode = deckOpen() ? 'deck' : '';
    stage.dataset.subject = selected;
    lead.textContent = selected === 'driver' ? 'Who is the fastest' : 'Which is the fastest';
    subjectTitle.textContent = selected === 'driver' ? 'Driver?' : 'car?';
    for (const subject of SUBJECTS) buttons[subject].setAttribute('aria-pressed', String(selected === subject));
    ledger.hidden = deckOpen();
    setEntity(selected);
    announcePanel();
  }

  for (const subject of SUBJECTS)
    buttons[subject].addEventListener('click', () => {
      selected = subject;
      update();
      window.dispatchEvent(new CustomEvent('f1:ratings-pinned', { detail: { pinned: true } }));
    });
  window.addEventListener('f1:entity-chosen', (event) => {
    selected = event.detail.entity;
    update();
  });
  window.addEventListener('f1:workspace-changed', () => {
    layout();
    update();
  });
  window.addEventListener('f1:ratings-failed', (event) => {
    stage.querySelector('.stage-tagline').textContent =
      `Could not load the ratings: ${event.detail?.message || 'unknown error'}. Reload the page to try again.`;
  });
  document.addEventListener('keydown', (event) => {
    if (
      event.key !== 'Escape' ||
      event.ctrlKey ||
      event.metaKey ||
      event.altKey ||
      event.defaultPrevented ||
      event.target instanceof HTMLSelectElement
    )
      return;
    if (!deckOpen() && ledger.dataset.view !== 'ratings') window.dispatchEvent(new CustomEvent('f1:ledger-back'));
  });
  const observer = new ResizeObserver(layout);
  observer.observe(stage);
  observer.observe(bottomBar);
  document.fonts?.ready.then(layout);
  stage.dataset.coarse = String(!matchMedia('(hover: hover) and (pointer: fine)').matches);
  layout();
  update();
}
