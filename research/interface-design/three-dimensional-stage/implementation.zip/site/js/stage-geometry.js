// The canvas, fixed selection targets and title share the same responsive layout.
export const ART = { width: 480, height: 960 };
export const SUBJECTS = {
  driver: { x: 20, y: 20, width: 440, height: 440 },
  car: { x: 20, y: 500, width: 440, height: 440 },
};
export const WIDE_MINIMUM = 1000;
export const edgeMargin = (width) => Math.min(72, Math.max(18, width * 0.05));
const modelColumnWidth = (width) => (width >= WIDE_MINIMUM ? Math.min(340, width * 0.23) : Math.min(156, width * 0.36));

export function panelColumn(width) {
  if (width < WIDE_MINIMUM) return null;
  const left = edgeMargin(width),
    panelWidth = width - 2 * left - modelColumnWidth(width) - 28;
  return { left, width: panelWidth, right: left + panelWidth };
}

export function titleLayout(viewportWidth) {
  const column = panelColumn(viewportWidth);
  const width = column?.width ?? viewportWidth - 2 * edgeMargin(viewportWidth) - modelColumnWidth(viewportWidth) - 18;
  const size = Math.min(60, Math.max(28, width * 0.16));
  const leadSize = Math.min(25, Math.max(17, width * 0.052));
  return { left: edgeMargin(viewportWidth), top: 80, width, size, leadSize, height: leadSize * 1.5 + size * 1.15 + 8 };
}

export function sceneGeometry(viewportWidth, viewportHeight) {
  const column = panelColumn(viewportWidth);
  const region = {
    left: viewportWidth - edgeMargin(viewportWidth) - modelColumnWidth(viewportWidth),
    width: modelColumnWidth(viewportWidth),
  };
  const scale = column ? Math.min(region.width / ART.width, Math.max(300, viewportHeight - 150) / ART.height) : region.width / ART.width;
  return {
    scale,
    x: viewportWidth - edgeMargin(viewportWidth) - ART.width * scale,
    y: column ? 80 : 72,
    width: ART.width * scale,
    height: ART.height * scale,
    artHeight: ART.height,
    viewports: SUBJECTS,
    region,
    wide: Boolean(column),
  };
}

export function toViewport(geometry, box) {
  return {
    x: geometry.x + box.x * geometry.scale,
    y: geometry.y + box.y * geometry.scale,
    width: box.width * geometry.scale,
    height: box.height * geometry.scale,
  };
}
export const subjectRectangle = (geometry, subject) => toViewport(geometry, geometry.viewports[subject]);
